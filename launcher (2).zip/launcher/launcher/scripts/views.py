import os
import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .runner import (
    start_all_scripts,
    stop_all_scripts,
    get_process_status,
    run_compiler,
    run_modem,
)
import psutil


SCRIPT_DIR = r"C:\Users\Akhil\Desktop\Vikrant\operation"
EXCLUDED_SCRIPTS = {"Compiler.py", "modem_reboot.py"}


# --- STAT FILES PATH ---
STATS_DIR = r"C:\Users\Akhil\Desktop\Vikrant\data\repo"
SCRAPER_STATS_FILE = os.path.join(STATS_DIR, "scraper_stats.json")
ZOHOO_STATS_FILE = os.path.join(STATS_DIR, "zoho_stats.json")



def home(request):
    try:
        scripts = [
            f for f in os.listdir(SCRIPT_DIR)
            if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
        ]
        scripts.sort()
    except FileNotFoundError:
        scripts = []

    return render(request, "launcher/index.html", {
        "scripts": scripts,
    })



def start_script(request):
    if request.method == "POST":
        script_name = request.GET.get("script")
        if script_name:
            result = start_all_scripts(script_name)
        else:
            result = start_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)



def stop_script(request):
    if request.method == "POST":
        result = stop_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)



def get_status(request):
    return JsonResponse(get_process_status())



def system_metrics(request):
    cpu_usage = psutil.cpu_percent(interval=0.2)
    return JsonResponse({
        "cpu_usage": round(cpu_usage, 1),
    })


def config(request):
    return render(request, "launcher/config.html")


# ← NEW: Advanced config view
def advanced_config(request):
    return render(request, "launcher/advanced.html")


# ← stats endpoint for Script Status table
def get_stats(request):
    try:
        with open(SCRAPER_STATS_FILE, "r", encoding="utf-8") as f:
            scraper_stats = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        scraper_stats = {}

    try:
        with open(ZOHOO_STATS_FILE, "r", encoding="utf-8") as f:
            zoho_stats = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        zoho_stats = {}

    # deduce which scripts actually exist from SCRAPER_STATS_FILE keys
    all_scripts = set(list(scraper_stats.keys()) + list(zoho_stats.get("scripts", {}).keys()))
    if not all_scripts:
        try:
            with open(SCRAPER_STATS_FILE, "r", encoding="utf-8") as f:
                _ = json.load(f)
                if isinstance(_, dict):
                    all_scripts = set(_.keys())
        except:
            all_scripts = set()

    # fall back to runner script list if nothing in stats yet
    if not all_scripts:
        try:
            all_scripts = {
                f for f in os.listdir(SCRIPT_DIR)
                if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
            }
        except:
            all_scripts = set()

    # build per‑script stats
    script_list = []
    for name in sorted(all_scripts):
        collected = 0
        for batch in scraper_stats.values():
            if isinstance(batch, dict) and "collected" in batch:
                collected += batch.get("collected", 0)

        # EXAMPLE: if you store by script in zoho_stats["scripts"]:
        pushed = 0
        if isinstance(zoho_stats, dict):
            scripts_in_zoho = zoho_stats.get("scripts", {})
            if isinstance(scripts_in_zoho, dict):
                pushed = scripts_in_zoho.get(name, {}).get("pushed_sent", 0)

        script_list.append({
            "name": name,
            "collected": collected,
            "pushed": pushed,
        })

    return JsonResponse({"scripts": script_list})



@require_POST
def run_compiler(request):
    result = run_compiler()
    return JsonResponse(result)



@require_POST
def run_modem(request):
    result = run_modem()
    return JsonResponse(result)