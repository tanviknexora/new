from django.urls import path
from django.http import HttpResponse
from . import views

urlpatterns = [
    # Main pages
    path('', views.home, name='home'),                                      # Config dashboard (launcher)

    # Config pages (new)
    path('config/', views.config, name='config'),                            # BASIC CONFIG page
    path('advanced/', views.advanced, name='advanced'),                      # ADVANCED CONFIG page

    # Config endpoints (AJAX / POST)
    path('save-config/', views.save_config, name='save_config'),           # Config save
    path('test-login/', views.test_login, name='test_login'),              # Test login

    # Script control
    path('start-script/', views.start_script, name='start_script'),
    path('stop-script/', views.stop_script, name='stop_script'),
    path('get-status/', views.get_status, name='get_status'),
    path('system-metrics/', views.system_metrics, name='system_metrics'),
    path('get-stats/', views.get_stats, name='get_stats'),

    # System tools
    path('run-compiler/', views.run_compiler, name='run_compiler'),
    path('run-modem/', views.run_modem, name='run_modem'),
]