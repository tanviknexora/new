import os
import json
import psutil
import subprocess
import threading
import time
from datetime import datetime

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST

SCRIPT_DIR = r"C:\Users\Akhil\Desktop\Vikrant\operation"
EXCLUDED_SCRIPTS = {"Compiler.py", "modem_reboot.py"}

STATS_DIR = r"C:\Users\Akhil\Desktop\Vikrant\data\repo"
SCRAPER_STATS_FILE = os.path.join(STATS_DIR, "scraper_stats.json")
ZOHOO_STATS_FILE = os.path.join(STATS_DIR, "zoho_stats.json")
SCRAPER_CONFIG_FILE = os.path.join(STATS_DIR, "scraper_config.json")

# Global process tracking
processes = {}
compiler_process = None
modem_process = None
process_status = {
    "running": False,
    "current": "idle",
    "scripts": {},
    "timestamp": None
}
process_status_lock = threading.Lock()

def log(message):
    """Simple logging function"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

def _popen_script(script_name):
    """Helper to start script subprocess"""
    script_path = os.path.join(SCRIPT_DIR, script_name)
    if not os.path.exists(script_path):
        raise FileNotFoundError(f"Script not found: {script_path}")
    
    process = subprocess.Popen(
        [script_path],
        cwd=SCRIPT_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    )
    return process

def _terminate_process(process):
    """Safely terminate a process"""
    if process and process.poll() is None:
        try:
            process.terminate()
            time.sleep(0.5)
            if process.poll() is None:
                process.kill()
        except:
            pass

# Runner functions (these were missing!)
def start_all_scripts(target_script=None):
    """Start all scripts or specific target script"""
    with process_status_lock:
        if process_status["running"]:
            return {"status": "already_running", "message": "Scripts already running"}
        
        process_status["running"] = True
        process_status["current"] = "starting"
        process_status["timestamp"] = time.time()
    
    log("Starting scripts...")
    
    try:
        if target_script:
            # Start specific script
            process = _popen_script(target_script)
            processes[target_script] = process
            log(f"Started {target_script} (PID: {process.pid})")
        else:
            # Start all scripts
            for script in os.listdir(SCRIPT_DIR):
                if script.endswith(".py") and script not in EXCLUDED_SCRIPTS:
                    process = _popen_script(script)
                    processes[script] = process
                    log(f"Started {script} (PID: {process.pid})")
                    time.sleep(0.2)  # Stagger starts
        
        with process_status_lock:
            process_status["current"] = "running"
        
        return {"status": "started", "scripts": list(processes.keys())}
    
    except Exception as e:
        log(f"Failed to start scripts: {e}")
        stop_all_scripts()
        return {"status": "error", "message": str(e)}

def stop_all_scripts():
    """Stop all running scripts"""
    log("Stopping all scripts...")
    
    with process_status_lock:
        process_status["running"] = False
        process_status["current"] = "stopping"
    
    # Terminate all processes
    for name, process in list(processes.items()):
        _terminate_process(process)
        log(f"Stopped {name}")
    
    _terminate_process(compiler_process)
    _terminate_process(modem_process)
    
    processes.clear()
    compiler_process = None
    modem_process = None
    
    with process_status_lock:
        process_status["current"] = "idle"
        process_status["scripts"] = {}
    
    log("All scripts stopped")
    return {"status": "stopped"}

def get_process_status():
    """Get current process status"""
    with process_status_lock:
        status = process_status.copy()
        status["active_processes"] = [
            {"name": name, "pid": p.pid if p.poll() is None else None}
            for name, p in processes.items()
        ]
        return status

def runner_run_compiler():
    """Run compiler manually"""
    global compiler_process
    
    if process_status["running"]:
        return {"status": "batch_running", "message": "Cannot run compiler during batch"}
    
    log("Manual compiler run requested")
    
    try:
        compiler_script = "Compiler.py"
        compiler_process = _popen_script(compiler_script)
        compiler_process.wait()
        log("Compiler completed")
        return {"status": "compiler_done"}
    except Exception as e:
        log(f"Compiler failed: {e}")
        return {"status": "error", "message": str(e)}

def runner_run_modem():
    """Run modem reboot manually"""
    global modem_process
    
    if process_status["running"]:
        return {"status": "batch_running", "message": "Cannot run modem during batch"}
    
    log("Manual modem reboot requested")
    
    try:
        modem_script = "modem_reboot.py"
        modem_process = _popen_script(modem_script)
        modem_process.wait()
        log("Modem reboot completed")
        return {"status": "modem_done"}
    except Exception as e:
        log(f"Modem reboot failed: {e}")
        return {"status": "error", "message": str(e)}

# Django views
def home(request):
    # Load scripts
    try:
        scripts = [
            f for f in os.listdir(SCRIPT_DIR)
            if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
        ]
        scripts.sort()
    except FileNotFoundError:
        scripts = []

    # Load config
    config = {
        "base_url": "https://affiliate.winfix.fun",
        "login_url": "https://affiliate.winfix.fun/login",
        "username": "",
        "password": "",
        "parent_ids": [],
        "output_path": r"C:\Users\Akhil\Desktop\Vikrant\data\input",
        "page_size": "100",
        "parallel_workers": "2",
        "advanced": {
            "selenium_version": "146",
            "login_username_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input',
            "login_password_xpath": '//*[@id="standard-adornment-password"]',
            "login_submit_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]',
        }
    }
    
    try:
        with open(SCRAPER_CONFIG_FILE, "r", encoding="utf-8") as f:
            config.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    return render(request, "launcher/index.html", {
        "scripts": scripts,
        "config": config,
    })

def start_script(request):
    if request.method == "POST":
        script_name = request.POST.get("script")
        if script_name:
            result = start_all_scripts(script_name)
        else:
            result = start_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)

def stop_script(request):
    if request.method == "POST":
        result = stop_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)

def get_status(request):
    return JsonResponse(get_process_status())

def system_metrics(request):
    cpu_usage = psutil.cpu_percent(interval=0.2)
    return JsonResponse({
        "cpu_usage": round(cpu_usage, 1),
    })

def get_stats(request):
    try:
        with open(SCRAPER_STATS_FILE, "r", encoding="utf-8") as f:
            scraper_stats = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        scraper_stats = {}

    try:
        with open(ZOHOO_STATS_FILE, "r", encoding="utf-8") as f:
            zoho_stats = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        zoho_stats = {}

    all_scripts = set(list(scraper_stats.keys()) + list(zoho_stats.get("scripts", {}).keys()))

    if not all_scripts:
        try:
            all_scripts = {
                f for f in os.listdir(SCRIPT_DIR)
                if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
            }
        except:
            all_scripts = set()

    script_list = []
    for name in sorted(all_scripts):
        collected = 0
        for batch in scraper_stats.values():
            if isinstance(batch, dict) and "collected" in batch:
                collected += batch.get("collected", 0)

        pushed = 0
        if isinstance(zoho_stats, dict):
            scripts_in_zoho = zoho_stats.get("scripts", {})
            if isinstance(scripts_in_zoho, dict):
                pushed = scripts_in_zoho.get(name, {}).get("pushed_sent", 0)

        script_list.append({
            "name": name,
            "collected": collected,
            "pushed": pushed,
        })

    return JsonResponse({"scripts": script_list})

@require_POST
def run_compiler(request):
    result = runner_run_compiler()
    return JsonResponse(result)

@require_POST
def run_modem(request):
    result = runner_run_modem()
    return JsonResponse(result)

@require_POST
def save_config(request):
    """Save scraper configuration from the form."""
    data = request.POST.dict()
    parent_ids_raw = data.get("parent_ids", "")
    parent_ids = []
    
    # Parse parent IDs from textarea (one per line)
    for line in parent_ids_raw.splitlines():
        stripped = line.strip()
        if stripped.isdigit():
            parent_ids.append(int(stripped))
    
    config = {
        "base_url": data.get("base_url", "https://affiliate.winfix.fun"),
        "login_url": data.get("login_url", "https://affiliate.winfix.fun/login"),
        "username": data.get("username", ""),
        "password": data.get("password", ""),
        "parent_ids": parent_ids,
        "output_path": data.get("output_path", r"C:\Users\Akhil\Desktop\Vikrant\data\input"),
        "page_size": data.get("page_size", "100"),
        "parallel_workers": data.get("parallel_workers", "2"),
        "advanced": {
            "selenium_version": data.get("selenium_version", "146"),
            "login_username_xpath": data.get("login_username_xpath", '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input'),
            "login_password_xpath": data.get("login_password_xpath", '//*[@id="standard-adornment-password"]'),
            "login_submit_xpath": data.get("login_submit_xpath", '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]'),
        }
    }
    
    os.makedirs(os.path.dirname(SCRAPER_CONFIG_FILE), exist_ok=True)
    with open(SCRAPER_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    
    return JsonResponse({
        "status": "saved", 
        "message": "Configuration saved successfully",
        "parent_count": len(parent_ids),
        "selenium_version": config["advanced"]["selenium_version"]
    })

@require_POST
def test_login(request):
    """Test login credentials (placeholder)."""
    username = request.POST.get("username", "")
    password = request.POST.get("password", "")
    
    if not username or not password:
        return JsonResponse({
            "status": "error", 
            "message": "Username and password required"
        }, status=400)
    
    return JsonResponse({
        "status": "success", 
        "message": "Login test passed (format validation)",
        "next_step": "Ready to save config"
    })