function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (const cookie of cookies) {
      const c = cookie.trim();
      if (c.startsWith(name + "=")) {
        cookieValue = decodeURIComponent(c.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}


async function postAction(url, data = null) {
  const csrftoken = getCookie("csrftoken");

  const options = {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "X-CSRFToken": csrftoken,
    },
  };

  if (data) {
    const formData = new FormData();
    Object.entries(data).forEach(([key, value]) => {
      formData.append(key, value);
    });
    options.body = formData;
  }

  const response = await fetch(url, options);

  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }

  return response.json();
}



// === DOM Elements (unchanged) ===
const logBox = document.querySelector(".terminal");
const batchState = document.getElementById("batch-state");
const progressValue = document.getElementById("progress-value");
const cpuValue = document.getElementById("cpu-value");
const modemState = document.getElementById("modem-state");
const statusTableBody = document.querySelector(".status-panel tbody");
const scriptGrid = document.getElementById("scriptGrid");

const timerInput = document.getElementById("timer-input");
const timerUnit = document.getElementById("timer-unit");
const timerDisplay = document.getElementById("timer-display");

let timerInterval = null;
let timerRunning = false;
let timerDurationSeconds = 0;
let timerRemainingSeconds = 0;
let autoCycleEnabled = false;
let timerWasStoppedManually = false;

let lastLogCount = 0;



// === Log / Timer helpers (unchanged) ===
function addLog(message) {
  const line = document.createElement("div");
  const now = new Date().toLocaleTimeString();
  line.textContent = `[${now}] ${message}`;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
}

function formatTime(totalSeconds) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds]
    .map((v) => String(v).padStart(2, "0"))
    .join(":");
}

function getSelectedDurationSeconds() {
  const value = parseInt(timerInput.value || "0", 10);
  const unit = timerUnit.value;

  if (unit === "hours") return value * 3600;
  if (unit === "minutes") return value * 60;
  return value;
}

function updateTimerDisplay() {
  timerDisplay.textContent = formatTime(timerRemainingSeconds);
}

function stopTimerLoop() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
  timerRunning = false;
  autoCycleEnabled = false;
}

function stopTimerManually() {
  timerWasStoppedManually = true;
  stopTimerLoop();
  addLog("Timer stopped");
  timerRemainingSeconds = getSelectedDurationSeconds();
  updateTimerDisplay();
}

function waitForBatchToFinish() {
  return new Promise((resolve) => {
    const poll = setInterval(async () => {
      try {
        const response = await fetch("/get-status/", {
          method: "GET",
          credentials: "same-origin",
          headers: {
            "X-Requested-With": "XMLHttpRequest",
          },
        });

        const data = await response.json();

        if (!data.running) {
          clearInterval(poll);
          resolve();
        }
      } catch (error) {
        clearInterval(poll);
        resolve();
      }
    }, 3000);
  });
}

async function startTimerLoop() {
  stopTimerLoop();
  timerWasStoppedManually = false;

  timerDurationSeconds = getSelectedDurationSeconds();
  if (timerDurationSeconds <= 0) {
    addLog("Timer value must be greater than 0");
    return;
  }

  timerRemainingSeconds = timerDurationSeconds;
  autoCycleEnabled = true;
  timerRunning = true;
  updateTimerDisplay();
  addLog("Timer started");

  const tick = async () => {
    if (!autoCycleEnabled) {
      stopTimerLoop();
      return;
    }

    timerRemainingSeconds -= 1;

    if (timerRemainingSeconds <= 0) {
      timerRemainingSeconds = 0;
      updateTimerDisplay();
      stopTimerLoop();

      try {
        const result = await postAction("/start-script/");
        addLog(result.status);
        await waitForBatchToFinish();
      } catch (error) {
        addLog("Batch start failed");
        console.error(error);
      }

      if (!timerWasStoppedManually) {
        startTimerLoop();
      }
      return;
    }

    updateTimerDisplay();
  };

  timerInterval = setInterval(tick, 1000);
}



// === Refresh Status (includes script stats) ===
async function getStats() {
  try {
    const response = await fetch("/get-stats/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!response.ok) {
      throw new Error(`Stats request failed: ${response.status}`);
    }

    return await response.json();
  } catch (e) {
    console.error("getStats error:", e);
    return { scripts: [] };
  }
}

async function refreshStatus() {
  try {
    const statusResp = await fetch("/get-status/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!statusResp.ok) {
      throw new Error(`Status request failed: ${statusResp.status}`);
    }

    const statusData = await statusResp.json();

    batchState.textContent = statusData.current || "idle";
    modemState.textContent = statusData.running ? "RUNNING" : "READY";
    progressValue.textContent = statusData.progress || "0/0";

    if (Array.isArray(statusData.logs)) {
      for (let i = lastLogCount; i < statusData.logs.length; i++) {
        addLog(statusData.logs[i]);
      }
      lastLogCount = statusData.logs.length;
    }

    const statsData = await getStats();
    const scriptStats = statsData.scripts || [];
    const running = statusData.running;

    const rows = scriptStats.map((s) => {
      const name = s.name || "unknown";
      const collected = s.collected || 0;
      const pushed = s.pushed || 0;

      return `
        <tr>
          <td>${name}</td>
          <td>
            <span class="badge ${running ? "running" : "completed"}">
              ${running ? "Running" : "Completed"}
            </span>
          </td>
          <td>---</td>
          <td>${statusData.progress || "0/0"}</td>
          <td>${collected}</td>
          <td>${pushed}</td>
        </tr>
      `;
    }).join("");

    statusTableBody.innerHTML = rows;
  } catch (error) {
    addLog("Failed to refresh status");
    console.error(error);
  }
}

async function refreshCpuUsage() {
  try {
    const response = await fetch("/system-metrics/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!response.ok) {
      throw new Error(`CPU request failed: ${response.status}`);
    }

    const data = await response.json();

    if (cpuValue) {
      cpuValue.textContent = `${data.cpu_usage}%`;
    }
  } catch (error) {
    if (cpuValue) {
      cpuValue.textContent = "--%";
    }
    console.error(error);
  }
}



// === Launcher actions (from index.html) ===
async function handleAction(action) {
  if (action === "start-all") {
    const result = await postAction("/start-script/");
    addLog(result.status);
    await refreshStatus();
    return;
  }

  if (action === "stop-all") {
    stopTimerManually();
    const result = await postAction("/stop-script/");
    addLog(result.status);
    await refreshStatus();
    return;
  }

  if (action === "refresh") {
    await refreshStatus();
    addLog("Status refreshed");
    return;
  }

  if (action === "reboot") {
    try {
      const result = await postAction("/run-modem/");
      addLog(`Modem: ${result.status}`);
    } catch (error) {
      addLog("Modem reboot failed");
      console.error(error);
    }
    return;
  }

  if (action === "run-compiler") {
    try {
      const result = await postAction("/run-compiler/");
      addLog(`Compiler: ${result.status}`);
    } catch (error) {
      addLog("Compiler failed");
      console.error(error);
    }
    return;
  }

  if (action === "timer-start") {
    await startTimerLoop();
    return;
  }

  if (action === "timer-stop") {
    stopTimerManually();
    return;
  }

  addLog(`${action} triggered`);
}



// Buttons with data-action (global)
document.querySelectorAll("[data-action]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const action = btn.dataset.action;
    try {
      await handleAction(action);
    } catch (error) {
      addLog("Action failed");
      console.error(error);
    }
  });
});



// Individual script cards (launcher page only)
if (scriptGrid) {
  scriptGrid.addEventListener("click", async (e) => {
    const btn = e.target.closest(".script-card");
    if (!btn) return;

    const scriptName = btn.dataset.script;
    if (!scriptName) return;

    try {
      addLog(`${scriptName} clicked`);
      const result = await postAction("/start-script/", { script: scriptName });
      addLog(result.status || `${scriptName} started`);
      await refreshStatus();
    } catch (error) {
      addLog(`Failed to start ${scriptName}`);
      console.error(error);
    }
  });
}



// Timer inputs (launcher page only)
timerInput.addEventListener("change", () => {
  if (timerRunning) {
    startTimerLoop();
  } else {
    timerRemainingSeconds = getSelectedDurationSeconds();
    updateTimerDisplay();
  }
});

timerUnit.addEventListener("change", () => {
  if (timerRunning) {
    startTimerLoop();
  } else {
    timerRemainingSeconds = getSelectedDurationSeconds();
    updateTimerDisplay();
  }
});



// Poll status + CPU (launcher page only)
setInterval(refreshStatus, 3000);
setInterval(refreshCpuUsage, 3000);

// Initial load (launcher page only)
refreshStatus();
refreshCpuUsage();



// === ONLY run on /scraper-config/ (config.html logic) ===
if (window.location.pathname.startsWith("/scraper-config")) {

  function getFormData(form) {
    const data = new FormData(form);
    const obj = {};
    for (const [key, value] of data.entries()) {
      obj[key] = value;
    }
    return obj;
  }

  function generateScript(config) {
    const parentIdsRaw = config.parent_ids || "";
    const parentIds = parentIdsRaw
      .split("\n")
      .map((x) => x.trim())
      .filter((x) => x !== "")
      .map((x) => parseInt(x, 10))
      .filter((x) => !isNaN(x));

    // Customize this part to match your real scraper_template.py
    const scriptCode = `"""
Scrap script for:
- Parent IDs: [${parentIds.join(", ")}]
- Selenium version: ${config.selenium_version || 146}
"""

import os
import json
import time
import traceback
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By


USERNAME = "${config.username || "winfix_bh"}"
PASSWORD = "${config.password || "tUWWsxK8w1Tv2"}"
PARENT_IDS = [${parentIds.join(", ")}]
OUTPUT_PATH = r"${config.output_path || "C:\\Users\\Akhil\\Desktop\\Vikrant\\data\\input"}"
SELENIUM_VERSION = "${config.selenium_version || "146"}"


def get_driver():
    # Placeholder: initialize your driver here
    pass


def run_scraper():
    # Placeholder: your scraping logic
    pass


if __name__ == "__main__":
    run_scraper()
`;

    return scriptCode;
  }

  async function handleTestLogin() {
    const form = document.getElementById("configForm");
    if (!form) return;

    const data = getFormData(form);
    const username = data.username;
    const password = data.password;

    if (!username || !password) {
      addLog("Login test: username and password required");
      return;
    }

    try {
      const result = await postAction("/test-login/", {
        username,
        password,
      });
      addLog(result.message);
    } catch (error) {
      addLog("Login test failed");
      console.error(error);
    }
  }

  async function handleSaveConfig() {
    const form = document.getElementById("configForm");
    if (!form) return;

    const data = getFormData(form);
    const formData = new FormData(form);

    await postAction("/save-config/", formData);
    addLog("Configuration saved");
  }

  function handleExportScript() {
    const form = document.getElementById("configForm");
    if (!form) return;

    const data = getFormData(form);
    const script = generateScript(data);

    const parentList = data.parent_ids || "";
    const firstParent = parentList
      .split("\n")
      .map((x) => x.trim())
      .filter((x) => x !== "")
      .shift() || "UNKNOWN";

    const filename = `scraper_${firstParent}.py`;

    const blob = new Blob([script], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

    addLog(`Script exported: ${filename}`);
  }

  // Hook config.html buttons
  document.querySelectorAll("[data-action='test-login']").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      handleTestLogin();
    });
  });

  document.querySelectorAll("[data-action='save-config']").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      handleSaveConfig();
    });
  });

  document.querySelectorAll("[data-action='export-script']").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      handleExportScript();
    });
  });

  // Optional: reset form
  document.querySelectorAll("[data-action='reset-config']").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.getElementById("configForm").reset();
      addLog("Form reset");
    });
  });
}