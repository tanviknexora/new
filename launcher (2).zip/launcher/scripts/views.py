import os
import json
import psutil
from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST, require_http_methods

from .runner import (
    start_all_scripts,
    stop_all_scripts,
    get_process_status,
    run_compiler as runner_run_compiler,
    run_modem as runner_run_modem,
)

# --- Paths ---
SCRIPT_DIR = r"C:\Users\Akhil\Desktop\Vikrant\operation"
EXCLUDED_SCRIPTS = {"Compiler.py", "modem_reboot.py"}

STATS_DIR = r"C:\Users\Akhil\Desktop\Vikrant\data\repo"
SCRAPER_STATS_FILE = os.path.join(STATS_DIR, "scraper_stats.json")
ZOHOO_STATS_FILE = os.path.join(STATS_DIR, "zoho_stats.json")
SCRAPER_CONFIG_FILE = os.path.join(STATS_DIR, "scraper_config.json")

TEMPLATE_PATH = r"C:\Users\Akhil\Desktop\Vikrant\scraper_template.py"  # your scraper template file


# === MAIN & CONFIG PAGES ===

def home(request):
    # Load scripts
    try:
        scripts = [
            f for f in os.listdir(SCRIPT_DIR)
            if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
        ]
        scripts.sort()
    except FileNotFoundError:
        scripts = []

    # Default config
    config = {
        "base_url": "https://affiliate.winfix.fun",
        "login_url": "https://affiliate.winfix.fun/login",
        "username": "",
        "password": "",
        "parent_ids": [],
        "output_path": r"C:\Users\Akhil\Desktop\Vikrant\data\input",
        "page_size": "100",
        "parallel_workers": "2",
        "advanced": {
            "selenium_version": "146",
            "login_username_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input',
            "login_password_xpath": '//*[@id="standard-adornment-password"]',
            "login_submit_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]',
        }
    }

    try:
        with open(SCRAPER_CONFIG_FILE, "r", encoding="utf-8") as f:
            config.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    return render(request, "launcher/index.html", {
        "scripts": scripts,
        "config": config,
    })


def config(request):
    # Render the BASIC CONFIG / Config Generator page
    config = {
        "base_url": "https://affiliate.winfix.fun",
        "login_url": "https://affiliate.winfix.fun/login",
        "username": "",
        "password": "",
        "parent_ids": [],
        "output_path": r"C:\Users\Akhil\Desktop\Vikrant\data\input",
        "page_size": "100",
        "parallel_workers": "2",
        "advanced": {
            "selenium_version": "146",
            "login_username_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input',
            "login_password_xpath": '//*[@id="standard-adornment-password"]',
            "login_submit_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]',
        }
    }

    try:
        with open(SCRAPER_CONFIG_FILE, "r", encoding="utf-8") as f:
            config.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    return render(request, "launcher/config.html", {
        "config": config,
    })


def advanced(request):
    # Render the ADVANCED CONFIG page
    config = {
        "base_url": "https://affiliate.winfix.fun",
        "login_url": "https://affiliate.winfix.fun/login",
        "username": "",
        "password": "",
        "parent_ids": [],
        "output_path": r"C:\Users\Akhil\Desktop\Vikrant\data\input",
        "page_size": "100",
        "parallel_workers": "2",
        "advanced": {
            "selenium_version": "146",
            "login_username_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input',
            "login_password_xpath": '//*[@id="standard-adornment-password"]',
            "login_submit_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]',
        }
    }

    try:
        with open(SCRAPER_CONFIG_FILE, "r", encoding="utf-8") as f:
            config.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    return render(request, "launcher/advanced.html", {
        "config": config,
    })


# === PROCESS & STATS ===

def start_script(request):
    if request.method == "POST":
        script_name = request.POST.get("script")
        if script_name:
            result = start_all_scripts(script_name)
        else:
            result = start_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)


def stop_script(request):
    if request.method == "POST":
        result = stop_all_scripts()
        return JsonResponse(result)
    return JsonResponse({"error": "POST required"}, status=405)


def get_status(request):
    return JsonResponse(get_process_status())


def system_metrics(request):
    cpu_usage = psutil.cpu_percent(interval=0.2)
    return JsonResponse({
        "cpu_usage": round(cpu_usage, 1),
    })


def get_stats(request):
    try:
        with open(SCRAPER_STATS_FILE, "r", encoding="utf-8") as f:
            scraper_stats = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        scraper_stats = {}

    try:
        with open(ZOHOO_STATS_FILE, "r", encoding="utf-8") as f:
            zoho_stats = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        zoho_stats = {}

    all_scripts = set(list(scraper_stats.keys()) + list(zoho_stats.get("scripts", {}).keys()))

    if not all_scripts:
        try:
            all_scripts = {
                f for f in os.listdir(SCRIPT_DIR)
                if f.endswith(".py") and f not in EXCLUDED_SCRIPTS
            }
        except:
            all_scripts = set()

    script_list = []
    for name in sorted(all_scripts):
        collected = 0
        for batch in scraper_stats.values():
            if isinstance(batch, dict) and "collected" in batch:
                collected += batch.get("collected", 0)

        pushed = 0
        if isinstance(zoho_stats, dict):
            scripts_in_zoho = zoho_stats.get("scripts", {})
            if isinstance(scripts_in_zoho, dict):
                pushed = scripts_in_zoho.get(name, {}).get("pushed_sent", 0)

        script_list.append({
            "name": name,
            "collected": collected,
            "pushed": pushed,
        })

    return JsonResponse({"scripts": script_list})


def get_config(request):
    """Return current scraper config as JSON for the script generator."""
    config = {
        "base_url": "https://affiliate.winfix.fun",
        "login_url": "https://affiliate.winfix.fun/login",
        "username": "",
        "password": "",
        "parent_ids": [],
        "output_path": r"C:\Users\Akhil\Desktop\Vikrant\data\input",
        "page_size": "100",
        "parallel_workers": "2",
        "advanced": {
            "selenium_version": "146",
            "login_username_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input',
            "login_password_xpath": '//*[@id="standard-adornment-password"]',
            "login_submit_xpath": '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]',
        }
    }

    try:
        with open(SCRAPER_CONFIG_FILE, "r", encoding="utf-8") as f:
            config.update(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    return JsonResponse(config)


# === SCRIPT GENERATOR VIEWS ===

@require_http_methods(["GET"])
def script_generator(request):
    """Script generator page"""
    config_file = os.path.join(STATS_DIR, "scraper_config.json")
    return render(request, "launcher/script_generator.html", {
        "config_file": config_file
    })


@require_POST
def generate_script(request):
    """Generate scraper script from config"""
    data = json.loads(request.body)

    # Load your original scraper code as template
    with open(TEMPLATE_PATH, 'r') as f:
        template = f.read()

    # Replace config values
    config = data.get("config", {})
    replaces = {
        "USERNAME_PLACEHOLDER": config.get("username", "winfix_bh"),
        "PASSWORD_PLACEHOLDER": config.get("password", "tUWWsxK8w1Tv2"),
        "PARENT_IDS_PLACEHOLDER": str(config.get("parent_ids", [17668090839])),
        "OUTPUT_PATH_PLACEHOLDER": config.get("output_path", r"C:\Users\Akhil\Desktop\Vikrant\data\input"),
        "SELENIUM_VERSION_PLACEHOLDER": (
            config.get("advanced", {}).get("selenium_version", "146")
        ),
    }

    script = template
    for placeholder, value in replaces.items():
        script = script.replace(f"{{{placeholder}}}", str(value))

    return JsonResponse({"script": script})


@require_POST
def export_script(request):
    """Export generated script as .py file (save to server + browser download)"""
    data = json.loads(request.body)
    script_code = data["script"]
    filename = data["filename"]

    # --- Save to server ---
    SCRIPTS_OUTPUT_DIR = r"C:\Users\Akhil\Desktop\Vikrant\generated_scripts"
    os.makedirs(SCRIPTS_OUTPUT_DIR, exist_ok=True)
    script_path = os.path.join(SCRIPTS_OUTPUT_DIR, filename)

    with open(script_path, "w", encoding="utf-8") as f:
        f.write(script_code)

    # --- Also send as download ---
    response = HttpResponse(script_code, content_type='text/plain')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


# === CONFIG IO & RUNNER ACTIONS ===

@require_POST
def save_config(request):
    """Save scraper configuration from the form."""
    data = request.POST.dict()
    parent_ids_raw = data.get("parent_ids", "")
    parent_ids = []

    # Parse parent IDs from textarea (one per line)
    for line in parent_ids_raw.splitlines():
        stripped = line.strip()
        if stripped.isdigit():
            parent_ids.append(int(stripped))

    config = {
        "base_url": data.get("base_url", "https://affiliate.winfix.fun"),
        "login_url": data.get("login_url", "https://affiliate.winfix.fun/login"),
        "username": data.get("username", ""),
        "password": data.get("password", ""),
        "parent_ids": parent_ids,
        "output_path": data.get("output_path", r"C:\Users\Akhil\Desktop\Vikrant\data\input"),
        "page_size": data.get("page_size", "100"),
        "parallel_workers": data.get("parallel_workers", "2"),
        "advanced": {
            "selenium_version": data.get("selenium_version", "146"),
            "login_username_xpath": data.get("login_username_xpath", '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input'),
            "login_password_xpath": data.get("login_password_xpath", '//*[@id="standard-adornment-password"]'),
            "login_submit_xpath": data.get("login_submit_xpath", '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]'),
        }
    }

    os.makedirs(os.path.dirname(SCRAPER_CONFIG_FILE), exist_ok=True)
    with open(SCRAPER_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    return JsonResponse({
        "status": "saved",
        "message": "Configuration saved successfully",
        "parent_count": len(parent_ids),
        "selenium_version": config["advanced"]["selenium_version"]
    })


@require_POST
def test_login(request):
    """Test login credentials (placeholder - implement actual test later)."""
    username = request.POST.get("username", "")
    password = request.POST.get("password", "")

    # For now, just validate format
    if not username or not password:
        return JsonResponse({
            "status": "error",
            "message": "Username and password required"
        }, status=400)

    return JsonResponse({
        "status": "success",
        "message": "Login test passed (format validation)",
        "next_step": "Ready to save config"
    })


@require_POST
def run_compiler(request):
    """Run compiler script."""
    result = runner_run_compiler()
    return JsonResponse(result)


@require_POST
def run_modem(request):
    """Run modem reboot script."""
    result = runner_run_modem()
    return JsonResponse(result)